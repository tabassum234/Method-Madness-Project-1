
public class Runner
{
	public static void main (String [] args) {
		LZouLib.sumUpTo(8);
		LZouLib.multiplicationTable(10);
		LZouLib.isPalindrome("1441");
	}
}

